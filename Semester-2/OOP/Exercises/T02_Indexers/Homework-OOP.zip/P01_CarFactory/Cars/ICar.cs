﻿namespace P01_CarFactory.Cars
{
    public interface ICar
    {
        string RegistrationNumber { get; set; }

        string Model { get; set; }
    }
}
